#include "Unary.hpp"
#include "../Node.hpp"

#include <map>
#include <string>

namespace AST::Op
{
    const std::map<Unary::Type, std::string>
        Unary::s_typeToString = {{Unary::Type::Chsign, "chsign"},
                                 {Unary::Type::Not, "not"},
                                 {Unary::Type::Random, "?"},
                                 {Unary::Type::Sizeof, "sizeof"}};

    Unary::Unary()
        : Node::Node()
    {
    }

    Unary::Unary(unsigned linenum)
        : Node::Node(linenum)
    {
    }

    Unary::Unary(unsigned linenum, Type type, Node *exp)
        : Node::Node(linenum),
          m_type(type)
    {
        addChild(exp);
    }

    void Unary::addExp(Node *exp)
    {
        if (m_children.size() > 0)
        {
            if (m_children[0] == nullptr)
            {
                m_children[0] = exp;
            }
            else
            {
                throw std::runtime_error("Unary operator cannot have more than one child.");
            }
        }
        else
        {
            addChild(exp);
        }
    }

    std::string Unary::toString() const
    {
        return "Op: " + s_typeToString.at(m_type) + lineTag();
    }
}