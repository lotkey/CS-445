#pragma once

namespace AST::Op
{
}

#include "Asgn.hpp"
#include "Binary.hpp"
#include "Unary.hpp"
#include "UnaryAsgn.hpp"