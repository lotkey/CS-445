#pragma once

#include "../Node.hpp"
#include "Stmt.hpp"

#include <string>

namespace AST::Stmt
{
    class Compound : public Stmt
    {
    public:
        Compound();
        /// @param linenum Line number the node appears on
        Compound(unsigned linenum);
        /// @param linenum Line number the node appears on
        /// @param localdecls Local declarations, use nullptr if none
        /// @param stmtlist Statement list, use nullptr if none
        Compound(unsigned linenum, Node *localdecls, Node *stmtlist);
    };
}