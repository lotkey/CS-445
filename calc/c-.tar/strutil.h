#ifndef STRUTIL_H
#define STRUTIL_H

#include <string.h>
#include <stdlib.h>

void removeQuotes(char* str, char** dest);
int getStrLen(char* str) ;
char getChar(char* str, int* index);
char* makeStr(char* str);

#endif